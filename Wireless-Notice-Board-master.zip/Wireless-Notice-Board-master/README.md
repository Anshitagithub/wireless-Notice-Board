# Wireless-Notice-Board
This github includes the complete code &amp; circuit of Wireless Notice Board Project using Arduino and Bluetooth Module.

To know more about this Project you can watch this Video: https://youtu.be/7TKmt7SyXgA
